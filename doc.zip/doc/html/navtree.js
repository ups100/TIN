var NAVTREE =
[
  [ "TIN", "index.html", [
    [ "Related Pages", "pages.html", [
      [ "Todo List", "todo.html", null ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "TIN_project::Server::Alias", "classTIN__project_1_1Server_1_1Alias.html", null ],
      [ "TIN_project::Client::AliasCommunicationListener", "classTIN__project_1_1Client_1_1AliasCommunicationListener.html", null ],
      [ "TIN_project::Utilities::AliasFileList", "classTIN__project_1_1Utilities_1_1AliasFileList.html", null ],
      [ "TIN_project::Utilities::AliasTree", "classTIN__project_1_1Utilities_1_1AliasTree.html", null ],
      [ "TIN_project::Client::Argument", "classTIN__project_1_1Client_1_1Argument.html", null ],
      [ "TIN_project::Client::ClientApplication", "classTIN__project_1_1Client_1_1ClientApplication.html", null ],
      [ "TIN_project::Daemon::ClientCommunication", "classTIN__project_1_1Daemon_1_1ClientCommunication.html", null ],
      [ "TIN_project::Server::ClientConnection", "classTIN__project_1_1Server_1_1ClientConnection.html", null ],
      [ "TIN_project::Server::ClientConnectionListener", "classTIN__project_1_1Server_1_1ClientConnectionListener.html", null ],
      [ "TIN_project::Client::ClientView", "classTIN__project_1_1Client_1_1ClientView.html", null ],
      [ "TIN_project::Client::CommandParser", "classTIN__project_1_1Client_1_1CommandParser.html", null ],
      [ "TIN_project::Client::Commands", "classTIN__project_1_1Client_1_1Commands.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< code, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 0, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_010_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 10, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0110_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 11, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0111_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 12, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0112_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 14, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0114_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 19, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0119_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 22, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0122_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 23, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0123_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 24, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0124_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 26, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0126_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 27, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0127_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 28, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0128_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 3, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_013_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 30, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0130_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 31, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0131_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 32, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0132_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 33, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0133_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 6, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_016_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 9, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_019_00_01T_01_4.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateAliasFileList", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateAliasFileList.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateAliasFileLocation", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateAliasFileLocation.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateBase", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateBase.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateMessage", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateMessage.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateName", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateName.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAddressAndPort", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAddressAndPort.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAddressPortAndSize", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAddressPortAndSize.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAndLong", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAndLong.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAndPassword", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAndPassword.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNamePasswordAndId", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNamePasswordAndId.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol", "classTIN__project_1_1Utilities_1_1CommunicationProtocol.html", null ],
      [ "TIN_project::Daemon::DaemonConfiguration::Config", "structTIN__project_1_1Daemon_1_1DaemonConfiguration_1_1Config.html", null ],
      [ "TIN_project::Utilities::ConfigFileName", "classTIN__project_1_1Utilities_1_1ConfigFileName.html", null ],
      [ "TIN_project::Daemon::DaemonApplication", "classTIN__project_1_1Daemon_1_1DaemonApplication.html", null ],
      [ "TIN_project::Client::DaemonCommunication", "classTIN__project_1_1Client_1_1DaemonCommunication.html", null ],
      [ "TIN_project::Daemon::DaemonConfiguration", "classTIN__project_1_1Daemon_1_1DaemonConfiguration.html", null ],
      [ "TIN_project::Server::DaemonConnection", "classTIN__project_1_1Server_1_1DaemonConnection.html", null ],
      [ "TIN_project::Server::DaemonConnectionListener", "classTIN__project_1_1Server_1_1DaemonConnectionListener.html", null ],
      [ "TIN_project::Daemon::DaemonThread", "classTIN__project_1_1Daemon_1_1DaemonThread.html", null ],
      [ "TIN_project::Daemon::DaemonThreadListener", "classTIN__project_1_1Daemon_1_1DaemonThreadListener.html", null ],
      [ "TIN_project::Utilities::FileLocation", "classTIN__project_1_1Utilities_1_1FileLocation.html", null ],
      [ "TIN_project::Daemon::FileReciver", "classTIN__project_1_1Daemon_1_1FileReciver.html", null ],
      [ "TIN_project::Daemon::FileSender", "classTIN__project_1_1Daemon_1_1FileSender.html", null ],
      [ "TIN_project::Daemon::FileTransferListener", "classTIN__project_1_1Daemon_1_1FileTransferListener.html", null ],
      [ "TIN_project::Server::FileTransferListener", "classTIN__project_1_1Server_1_1FileTransferListener.html", null ],
      [ "TIN_project::Server::FileTransferServer", "classTIN__project_1_1Server_1_1FileTransferServer.html", null ],
      [ "TIN_project::Utilities::Identifier", "classTIN__project_1_1Utilities_1_1Identifier.html", null ],
      [ "TIN_project::Utilities::Identify", "classTIN__project_1_1Utilities_1_1Identify.html", null ],
      [ "TIN_project::Utilities::InterprocessName", "classTIN__project_1_1Utilities_1_1InterprocessName.html", null ],
      [ "TIN_project::Utilities::AliasTree::Location", "structTIN__project_1_1Utilities_1_1AliasTree_1_1Location.html", null ],
      [ "TIN_project::Server::MainServer", "classTIN__project_1_1Server_1_1MainServer.html", null ],
      [ "TIN_project::Utilities::Message", "classTIN__project_1_1Utilities_1_1Message.html", null ],
      [ "TIN_project::Utilities::Password", "classTIN__project_1_1Utilities_1_1Password.html", null ],
      [ "TIN_project::Daemon::ServerConnection", "classTIN__project_1_1Daemon_1_1ServerConnection.html", null ],
      [ "TIN_project::Client::ServerConnection", "classTIN__project_1_1Client_1_1ServerConnection.html", null ],
      [ "TIN_project::Client::ServerConnectionListener", "classTIN__project_1_1Client_1_1ServerConnectionListener.html", null ],
      [ "TIN_project::Daemon::ServerConnectionListener", "classTIN__project_1_1Daemon_1_1ServerConnectionListener.html", null ],
      [ "TIN_project::Server::TcpServer", "classTIN__project_1_1Server_1_1TcpServer.html", null ],
      [ "TIN_project::Server::UnknownConnection", "classTIN__project_1_1Server_1_1UnknownConnection.html", null ],
      [ "TIN_project::Server::UnknownConnectionListener", "classTIN__project_1_1Server_1_1UnknownConnectionListener.html", null ]
    ] ],
    [ "Data Structure Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "TIN_project::Client::AliasCommunicationListener", "classTIN__project_1_1Client_1_1AliasCommunicationListener.html", [
        [ "TIN_project::Client::ClientApplication", "classTIN__project_1_1Client_1_1ClientApplication.html", null ]
      ] ],
      [ "TIN_project::Utilities::AliasFileList", "classTIN__project_1_1Utilities_1_1AliasFileList.html", null ],
      [ "TIN_project::Utilities::AliasTree", "classTIN__project_1_1Utilities_1_1AliasTree.html", null ],
      [ "TIN_project::Client::Argument", "classTIN__project_1_1Client_1_1Argument.html", null ],
      [ "TIN_project::Daemon::ClientCommunication", "classTIN__project_1_1Daemon_1_1ClientCommunication.html", null ],
      [ "TIN_project::Server::ClientConnection", "classTIN__project_1_1Server_1_1ClientConnection.html", null ],
      [ "TIN_project::Server::ClientConnectionListener", "classTIN__project_1_1Server_1_1ClientConnectionListener.html", [
        [ "TIN_project::Server::Alias", "classTIN__project_1_1Server_1_1Alias.html", null ]
      ] ],
      [ "TIN_project::Client::ClientView", "classTIN__project_1_1Client_1_1ClientView.html", null ],
      [ "TIN_project::Client::CommandParser", "classTIN__project_1_1Client_1_1CommandParser.html", null ],
      [ "TIN_project::Client::Commands", "classTIN__project_1_1Client_1_1Commands.html", null ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateAliasFileList", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateAliasFileList.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 10, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0110_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 12, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0112_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 26, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0126_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 30, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0130_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateAliasFileLocation", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateAliasFileLocation.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 14, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0114_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateBase", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateBase.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< code, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 0, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_010_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 10, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0110_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 11, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0111_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 12, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0112_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 14, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0114_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 19, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0119_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 22, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0122_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 23, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0123_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 24, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0124_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 26, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0126_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 27, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0127_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 28, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0128_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 3, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_013_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 30, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0130_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 31, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0131_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 32, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0132_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 33, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0133_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 6, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_016_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 9, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_019_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateMessage", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateMessage.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 32, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0132_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 33, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0133_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateName", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateName.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 11, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0111_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 19, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0119_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 27, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0127_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 28, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0128_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAddressAndPort", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAddressAndPort.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 24, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0124_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAddressPortAndSize", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAddressPortAndSize.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 23, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0123_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAndLong", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAndLong.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 22, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0122_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNameAndPassword", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNameAndPassword.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 3, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_013_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 6, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_016_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol::CommunicateNamePasswordAndId", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1CommunicateNamePasswordAndId.html", [
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 0, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_010_00_01T_01_4.html", null ],
        [ "TIN_project::Utilities::CommunicationProtocol::Communicate< 31, T >", "classTIN__project_1_1Utilities_1_1CommunicationProtocol_1_1Communicate_3_0131_00_01T_01_4.html", null ]
      ] ],
      [ "TIN_project::Utilities::CommunicationProtocol", "classTIN__project_1_1Utilities_1_1CommunicationProtocol.html", null ],
      [ "TIN_project::Daemon::DaemonConfiguration::Config", "structTIN__project_1_1Daemon_1_1DaemonConfiguration_1_1Config.html", null ],
      [ "TIN_project::Utilities::ConfigFileName", "classTIN__project_1_1Utilities_1_1ConfigFileName.html", null ],
      [ "TIN_project::Client::DaemonCommunication", "classTIN__project_1_1Client_1_1DaemonCommunication.html", null ],
      [ "TIN_project::Daemon::DaemonConfiguration", "classTIN__project_1_1Daemon_1_1DaemonConfiguration.html", null ],
      [ "TIN_project::Server::DaemonConnection", "classTIN__project_1_1Server_1_1DaemonConnection.html", null ],
      [ "TIN_project::Server::DaemonConnectionListener", "classTIN__project_1_1Server_1_1DaemonConnectionListener.html", [
        [ "TIN_project::Server::Alias", "classTIN__project_1_1Server_1_1Alias.html", null ]
      ] ],
      [ "TIN_project::Daemon::DaemonThreadListener", "classTIN__project_1_1Daemon_1_1DaemonThreadListener.html", [
        [ "TIN_project::Daemon::DaemonApplication", "classTIN__project_1_1Daemon_1_1DaemonApplication.html", null ]
      ] ],
      [ "TIN_project::Utilities::FileLocation", "classTIN__project_1_1Utilities_1_1FileLocation.html", null ],
      [ "TIN_project::Daemon::FileReciver", "classTIN__project_1_1Daemon_1_1FileReciver.html", null ],
      [ "TIN_project::Daemon::FileSender", "classTIN__project_1_1Daemon_1_1FileSender.html", null ],
      [ "TIN_project::Daemon::FileTransferListener", "classTIN__project_1_1Daemon_1_1FileTransferListener.html", [
        [ "TIN_project::Daemon::DaemonThread", "classTIN__project_1_1Daemon_1_1DaemonThread.html", null ]
      ] ],
      [ "TIN_project::Server::FileTransferListener", "classTIN__project_1_1Server_1_1FileTransferListener.html", [
        [ "TIN_project::Server::Alias", "classTIN__project_1_1Server_1_1Alias.html", null ]
      ] ],
      [ "TIN_project::Server::FileTransferServer", "classTIN__project_1_1Server_1_1FileTransferServer.html", null ],
      [ "TIN_project::Utilities::Identifier", "classTIN__project_1_1Utilities_1_1Identifier.html", null ],
      [ "TIN_project::Utilities::Identify", "classTIN__project_1_1Utilities_1_1Identify.html", null ],
      [ "TIN_project::Utilities::InterprocessName", "classTIN__project_1_1Utilities_1_1InterprocessName.html", null ],
      [ "TIN_project::Utilities::AliasTree::Location", "structTIN__project_1_1Utilities_1_1AliasTree_1_1Location.html", null ],
      [ "TIN_project::Utilities::Message", "classTIN__project_1_1Utilities_1_1Message.html", null ],
      [ "TIN_project::Utilities::Password", "classTIN__project_1_1Utilities_1_1Password.html", null ],
      [ "TIN_project::Daemon::ServerConnection", "classTIN__project_1_1Daemon_1_1ServerConnection.html", null ],
      [ "TIN_project::Client::ServerConnection", "classTIN__project_1_1Client_1_1ServerConnection.html", null ],
      [ "TIN_project::Client::ServerConnectionListener", "classTIN__project_1_1Client_1_1ServerConnectionListener.html", [
        [ "TIN_project::Client::ClientApplication", "classTIN__project_1_1Client_1_1ClientApplication.html", null ]
      ] ],
      [ "TIN_project::Daemon::ServerConnectionListener", "classTIN__project_1_1Daemon_1_1ServerConnectionListener.html", [
        [ "TIN_project::Daemon::DaemonThread", "classTIN__project_1_1Daemon_1_1DaemonThread.html", null ]
      ] ],
      [ "TIN_project::Server::TcpServer", "classTIN__project_1_1Server_1_1TcpServer.html", null ],
      [ "TIN_project::Server::UnknownConnection", "classTIN__project_1_1Server_1_1UnknownConnection.html", null ],
      [ "TIN_project::Server::UnknownConnectionListener", "classTIN__project_1_1Server_1_1UnknownConnectionListener.html", [
        [ "TIN_project::Server::MainServer", "classTIN__project_1_1Server_1_1MainServer.html", null ]
      ] ]
    ] ],
    [ "Data Fields", "functions.html", null ],
    [ "Namespace List", "namespaces.html", [
      [ "TIN_project", "namespaceTIN__project.html", null ],
      [ "TIN_project::Client", "namespaceTIN__project_1_1Client.html", null ],
      [ "TIN_project::Daemon", "namespaceTIN__project_1_1Daemon.html", null ],
      [ "TIN_project::Server", "namespaceTIN__project_1_1Server.html", null ],
      [ "TIN_project::Utilities", "namespaceTIN__project_1_1Utilities.html", null ]
    ] ],
    [ "Namespace Members", "namespacemembers.html", null ],
    [ "File List", "files.html", [
      [ "Alias.cpp", "Alias_8cpp.html", null ],
      [ "Alias.h", "Alias_8h.html", null ],
      [ "AliasCommunicationListener.cpp", "AliasCommunicationListener_8cpp.html", null ],
      [ "AliasCommunicationListener.h", "AliasCommunicationListener_8h.html", null ],
      [ "AliasFileList.cpp", "AliasFileList_8cpp.html", null ],
      [ "AliasFileList.h", "AliasFileList_8h.html", null ],
      [ "AliasTree.cpp", "AliasTree_8cpp.html", null ],
      [ "AliasTree.h", "AliasTree_8h.html", null ],
      [ "Argument.cpp", "Argument_8cpp.html", null ],
      [ "Argument.h", "Argument_8h.html", null ],
      [ "ClientApplication.cpp", "ClientApplication_8cpp.html", null ],
      [ "ClientApplication.h", "ClientApplication_8h.html", null ],
      [ "ClientCommunication.cpp", "ClientCommunication_8cpp.html", null ],
      [ "ClientCommunication.h", "ClientCommunication_8h.html", null ],
      [ "ClientConnection.cpp", "ClientConnection_8cpp.html", null ],
      [ "ClientConnection.h", "ClientConnection_8h.html", null ],
      [ "ClientConnectionListener.cpp", "ClientConnectionListener_8cpp.html", null ],
      [ "ClientConnectionListener.h", "ClientConnectionListener_8h.html", null ],
      [ "ClientView.cpp", "ClientView_8cpp.html", null ],
      [ "ClientView.h", "ClientView_8h.html", null ],
      [ "CommandParser.cpp", "CommandParser_8cpp.html", null ],
      [ "CommandParser.h", "CommandParser_8h.html", null ],
      [ "Commands.cpp", "Commands_8cpp.html", null ],
      [ "Commands.h", "Commands_8h.html", null ],
      [ "CommunicationProtocol.cpp", "CommunicationProtocol_8cpp.html", null ],
      [ "CommunicationProtocol.h", "CommunicationProtocol_8h.html", null ],
      [ "ConfigFileName.cpp", "ConfigFileName_8cpp.html", null ],
      [ "ConfigFileName.h", "ConfigFileName_8h.html", null ],
      [ "DaemonApplication.cpp", "DaemonApplication_8cpp.html", null ],
      [ "DaemonApplication.h", "DaemonApplication_8h.html", null ],
      [ "DaemonCommunication.cpp", "DaemonCommunication_8cpp.html", null ],
      [ "DaemonCommunication.h", "DaemonCommunication_8h.html", null ],
      [ "DaemonConfiguration.cpp", "DaemonConfiguration_8cpp.html", null ],
      [ "DaemonConfiguration.h", "DaemonConfiguration_8h.html", null ],
      [ "DaemonConnection.cpp", "DaemonConnection_8cpp.html", null ],
      [ "DaemonConnection.h", "DaemonConnection_8h.html", null ],
      [ "DaemonConnectionListener.cpp", "DaemonConnectionListener_8cpp.html", null ],
      [ "DaemonConnectionListener.h", "DaemonConnectionListener_8h.html", null ],
      [ "DaemonThread.cpp", "DaemonThread_8cpp.html", null ],
      [ "DaemonThread.h", "DaemonThread_8h.html", null ],
      [ "DaemonThreadListener.cpp", "DaemonThreadListener_8cpp.html", null ],
      [ "DaemonThreadListener.h", "DaemonThreadListener_8h.html", null ],
      [ "FileLocation.cpp", "FileLocation_8cpp.html", null ],
      [ "FileLocation.h", "FileLocation_8h.html", null ],
      [ "FileReciver.cpp", "FileReciver_8cpp.html", null ],
      [ "FileReciver.h", "FileReciver_8h.html", null ],
      [ "FileSender.cpp", "FileSender_8cpp.html", null ],
      [ "FileSender.h", "FileSender_8h.html", null ],
      [ "Daemon/src/FileTransferListener.cpp", "Daemon_2src_2FileTransferListener_8cpp.html", null ],
      [ "Server/src/FileTransferListener.cpp", "Server_2src_2FileTransferListener_8cpp.html", null ],
      [ "Daemon/include/FileTransferListener.h", "Daemon_2include_2FileTransferListener_8h.html", null ],
      [ "Server/include/FileTransferListener.h", "Server_2include_2FileTransferListener_8h.html", null ],
      [ "FileTransferServer.cpp", "FileTransferServer_8cpp.html", null ],
      [ "FileTransferServer.h", "FileTransferServer_8h.html", null ],
      [ "Identifier.cpp", "Identifier_8cpp.html", null ],
      [ "Identifier.h", "Identifier_8h.html", null ],
      [ "Identify.cpp", "Identify_8cpp.html", null ],
      [ "Identify.h", "Identify_8h.html", null ],
      [ "InterprocessName.cpp", "InterprocessName_8cpp.html", null ],
      [ "InterprocessName.h", "InterprocessName_8h.html", null ],
      [ "Client/src/main.cpp", "Client_2src_2main_8cpp.html", null ],
      [ "Daemon/src/main.cpp", "Daemon_2src_2main_8cpp.html", null ],
      [ "Server/src/main.cpp", "Server_2src_2main_8cpp.html", null ],
      [ "MainServer.cpp", "MainServer_8cpp.html", null ],
      [ "MainServer.h", "MainServer_8h.html", null ],
      [ "Message.cpp", "Message_8cpp.html", null ],
      [ "Message.h", "Message_8h.html", null ],
      [ "Password.cpp", "Password_8cpp.html", null ],
      [ "Password.h", "Password_8h.html", null ],
      [ "Client/src/ServerConnection.cpp", "Client_2src_2ServerConnection_8cpp.html", null ],
      [ "Daemon/src/ServerConnection.cpp", "Daemon_2src_2ServerConnection_8cpp.html", null ],
      [ "Client/include/ServerConnection.h", "Client_2include_2ServerConnection_8h.html", null ],
      [ "Daemon/include/ServerConnection.h", "Daemon_2include_2ServerConnection_8h.html", null ],
      [ "Client/src/ServerConnectionListener.cpp", "Client_2src_2ServerConnectionListener_8cpp.html", null ],
      [ "Daemon/src/ServerConnectionListener.cpp", "Daemon_2src_2ServerConnectionListener_8cpp.html", null ],
      [ "Client/include/ServerConnectionListener.h", "Client_2include_2ServerConnectionListener_8h.html", null ],
      [ "Daemon/include/ServerConnectionListener.h", "Daemon_2include_2ServerConnectionListener_8h.html", null ],
      [ "TcpServer.cpp", "TcpServer_8cpp.html", null ],
      [ "TcpServer.h", "TcpServer_8h.html", null ],
      [ "UnknownConnection.cpp", "UnknownConnection_8cpp.html", null ],
      [ "UnknownConnection.h", "UnknownConnection_8h.html", null ],
      [ "UnknownConnectionListener.cpp", "UnknownConnectionListener_8cpp.html", null ],
      [ "UnknownConnectionListener.h", "UnknownConnectionListener_8h.html", null ]
    ] ],
    [ "Directories", "dirs.html", [
      [ "code", "dir_4a345b1b06d042f0db0946faab9735e6.html", [
        [ "Client", "dir_77750565be38f4a3662663e35db194e9.html", [
          [ "include", "dir_afb1b0ac3988095c3d030e9705d4b285.html", null ],
          [ "src", "dir_58f8346339e09e19b47eec28fcbfd6f6.html", null ]
        ] ],
        [ "Daemon", "dir_34a28403fa5a5a57548a6b090faa2bce.html", [
          [ "include", "dir_8cacd883e754173b1ecfcc589a935bea.html", null ],
          [ "src", "dir_ead9c86e296bdae635da1c8c4a15a833.html", null ]
        ] ],
        [ "Server", "dir_962444ba3fd759acfb2436a2470fbb4f.html", [
          [ "include", "dir_62a85d007d328877a43c951f86d913c1.html", null ],
          [ "src", "dir_5fc9870b85fd45ce3c54a75780f598b8.html", null ]
        ] ],
        [ "Utilities", "dir_6b44d3d5e6b5b2dbb73d5ba9acdc8d96.html", [
          [ "include", "dir_71c491959bfbe622d112dc4fd7a154c6.html", null ],
          [ "src", "dir_0b1d5cb83065d48194c266d1fa8377e5.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Globals", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

